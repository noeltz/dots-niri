#!/bin/bash

launch_rofi() {
	rofi -show drun \
		 -theme $HOME/.config/rofi/themes/launcher.rasi
}

launch_rofi
