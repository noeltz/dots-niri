return {
	"danilamihailov/beacon.nvim",
}
