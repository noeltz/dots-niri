return {
	"karb94/neoscroll.nvim",
	opts = {},
}
