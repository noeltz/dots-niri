-- Lazy plugin manager
require("config.lazy")

-- Lsp Server
require("config.lsp")

-- Neovim Options
require("config.options")
